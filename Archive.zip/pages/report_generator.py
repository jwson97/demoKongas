import streamlit as st

def app():
    st.title("생성형 AI를 활용한 보고서 생성")
    st.write("생성형 AI를 활용해 보고서, 공문, 엑셀 파일 등을 자동 생성하는 기능입니다.")

import streamlit as st

def app():
    st.title("공사 특화 스케쥴러")
    st.write("우리공사의 주요 스케줄을 관리할 수 있는 특화된 스케쥴러 기능입니다.")
